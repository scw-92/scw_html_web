# ARM Settings Page

* 这个PHP网站主要用于获取、设置设备信息，除了直接在浏览器中设置主板信息、查看传感器数据外，你还可以直接通过HTTP协议直接进行设置;
* 加入WebSocket实时通信的支持;

## Show Picture

![image/ARM-Settings.png](image/ARM-Settings.png)
