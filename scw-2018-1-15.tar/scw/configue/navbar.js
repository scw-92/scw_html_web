//tools 级别是导航栏菜单
//ftp/csdn是下拉按钮菜单
//文件名规则：举例ftp(src/tools/ftp/thp.html,src/tools/ftp/thp.css,src/tools/ftp/thp.js)
var configures =
[
	
		{
			"tools":
				[
					"_html",
					"ftp",
					"ssh",
					"mqtt",
					"rtc",
					"uart",
					"eeprom"
				]
		},
		{
		"database":
			[
				"sbc_7112",
				"sbc_7109"
			]
		},
		{
		"netsite":
			[	{"rul":"#"},
				{"csdn":"http://blog.csdn.net/qq_39101111/article/details/78790779"},
				{"git":"https://githup.com/scw-92/"}
			]
		}
]
